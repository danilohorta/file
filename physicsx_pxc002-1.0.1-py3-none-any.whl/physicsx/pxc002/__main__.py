from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence

from physicsx.pxc002._component import resolve_component
from physicsx.pxc002._entrypoint import resolve_entrypoint
from physicsx.pxc002._execute import execute


def main(argv: Sequence[str] | None = None) -> int:
    """Run a PhysicsX component by its component name.

    Args:
        argv: Command-line arguments. If None, uses sys.argv.

    Returns:
        Exit code from the component execution.
    """
    parser = argparse.ArgumentParser(
        prog="pxc002",
        description="Run a PhysicsX component by its component name",
    )
    parser.add_argument(
        "component_name",
        help="Component name to identify and load the component",
    )

    args = parser.parse_args(argv)

    function = resolve_entrypoint(args.component_name).load()
    component = resolve_component(function)

    exit_code = execute(
        component=component, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr
    )

    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())

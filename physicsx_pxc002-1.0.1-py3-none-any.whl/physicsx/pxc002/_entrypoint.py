import importlib.metadata


def resolve_entrypoint(component_name: str) -> importlib.metadata.EntryPoint:
    """TODO: write docstring"""
    entry_points = importlib.metadata.entry_points(group="physicsx.components")
    for entry_point in entry_points:
        if entry_point.name == component_name:
            return entry_point

    available = [entry_point.name for entry_point in entry_points]
    raise LookupError(f"Component '{component_name}' not found. Available: {available}")

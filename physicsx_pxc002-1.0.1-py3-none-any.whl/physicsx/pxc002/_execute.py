"""Core PXC-002 process execution logic."""

from __future__ import annotations

import json
import traceback
from typing import TextIO

from physicsx.pxc002._component import Component


def execute(
    component: Component,
    stdin: TextIO,
    stdout: TextIO,
    stderr: TextIO,
) -> int:
    """Execute a component by reading JSON input from stdin and writing output to stdout.

    Args:
        component: The component to execute.
        stdin: Input stream to read JSON data from.
        stdout: Output stream to write JSON results to.
        stderr: Error stream to write error messages to.

    Returns:
        Exit code: 0 on success, 1 on any error.
    """
    try:
        input_text = stdin.readline()
        input_dict = json.loads(input_text)
        validated_input = component.input_type.model_validate(input_dict)
        output = component.function(validated_input)
        output_json = output.model_dump_json()
        stdout.write(output_json)
        stdout.write("\n")  # Newline termination required
        stdout.flush()
        return 0
    except Exception:
        stderr.write(traceback.format_exc())
        stderr.flush()
        return 1
